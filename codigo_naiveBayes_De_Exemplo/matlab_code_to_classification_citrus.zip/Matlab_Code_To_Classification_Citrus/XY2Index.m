function Vs = XY2Index(Vsx,Vsy,baris) 
Vs=Vsy*baris + Vsx - baris;












